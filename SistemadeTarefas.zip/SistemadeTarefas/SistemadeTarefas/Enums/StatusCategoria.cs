﻿using System.ComponentModel;

namespace SistemadeTarefas.Enums
{
    public enum StatusCategoria
    {
        [Description("Ativo")]
        AFazer = 1,
        [Description("Inativo")]
        EMAndamento = 2

    }
}
