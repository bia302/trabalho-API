﻿using Microsoft.EntityFrameworkCore;
using SistemadeTarefas.Data;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Repositarios
{
    public class PedidosRepositorio : IPedidosRepositorio
    {
        private readonly SistemaTarefasDbContext _Dbcontext;

        public PedidosRepositorio(SistemaTarefasDbContext SistemaTarefasContext)
        {
            _Dbcontext = SistemaTarefasContext;
        }


        public async Task<PedidosModel> BuscarPorId(int id)
        {
            return await _Dbcontext.Pedidos.FirstOrDefaultAsync(X => X.Id == id);
        }

        public async Task<List<PedidosModel>> BuscarTodosPedidos()
        {
            return await _Dbcontext.Pedidos.ToListAsync();
        }
        public async Task<PedidosModel> Adicionar(PedidosModel Pedidos)
        {
            await _Dbcontext.Pedidos.AddAsync(Pedidos);
            await _Dbcontext.SaveChangesAsync();

            return Pedidos;
        }

        public async Task<bool> Apagar(int id)
        {
            PedidosModel Pedidos = await BuscarPorId(id);
            if (Pedidos == null)
            {
                throw new Exception($"Pedidos do id: {id} não foi encontrado.");
            }

            _Dbcontext.Pedidos.Remove(Pedidos);
            await _Dbcontext.SaveChangesAsync();
            return true;
        }


        public async Task<PedidosModel> Atualizar(PedidosModel Pedidos, int id)
        {
            PedidosModel PedidosPorId = await BuscarPorId(id);

            if (PedidosPorId == null)
            {
                throw new Exception($"Pedidos do id: {id} não foi encontrado.");
            }
            PedidosPorId.DataEntrega = Pedidos.DataEntrega;
            PedidosPorId.Usuario = Pedidos.Usuario;

            _Dbcontext.Pedidos.Update(PedidosPorId);
            await _Dbcontext.SaveChangesAsync();

            return PedidosPorId;
        }


    }
}
