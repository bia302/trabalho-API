﻿using SistemadeTarefas.Models;

namespace SistemadeTarefas.Repositarios.Interfaces
{
    public interface IUsuarioRepositorio
    {
        Task<List<UsuariosModel>> BuscarTodosUsuarios();
        Task<UsuariosModel> BuscarPorId(int id);
        Task<UsuariosModel> Adicionar(UsuariosModel Usuario);
        Task<UsuariosModel> Atualizar(UsuariosModel Usuario, int id);
        Task<bool> Apagar(int id);
    }
}
