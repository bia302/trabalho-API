﻿using SistemadeTarefas.Models;

namespace SistemadeTarefas.Repositarios.Interfaces
{
    public interface ICategoriaRepositorio
    {
        Task<List<CategoriaModel>> BuscarTodasCategoria();
        Task<CategoriaModel> BuscarPorIdCategoria(int id);
        Task<CategoriaModel> Adicionar(CategoriaModel Categoria);
        Task<CategoriaModel> Atualizar(CategoriaModel Categoria, int id);
        Task<bool> Apagar(int id);
    }
}
