﻿using SistemadeTarefas.Models;

namespace SistemadeTarefas.Repositarios.Interfaces
{
    public interface IProdutoRepositorio
    {
        Task<List<ProdutosModel>> BuscarTodosProdutos();
        Task<ProdutosModel> BuscarPorId(int id);
        Task<ProdutosModel> Adicionar(ProdutosModel Produtos);
        Task<ProdutosModel> Atualizar(ProdutosModel Produtos, int id);
        Task<bool> Apagar(int id);
    }
}
