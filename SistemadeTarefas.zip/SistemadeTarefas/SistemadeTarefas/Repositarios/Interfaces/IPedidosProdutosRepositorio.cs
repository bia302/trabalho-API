﻿using SistemadeTarefas.Models;

namespace SistemadeTarefas.Repositarios.Interfaces
{
    public interface IPedidosProdutosRepositorio
    {
        Task<List<PedidosProdutosModel>> BuscarTodosPedidosProdutos();
        Task<PedidosProdutosModel> BuscarPorId(int id);
        Task<PedidosProdutosModel> Adicionar(PedidosProdutosModel PedidosProdutos);
        Task<PedidosProdutosModel> Atualizar(PedidosProdutosModel PedidosProdutos, int id);
        Task<bool> Apagar(int id);
    }
}
