﻿using SistemadeTarefas.Models;

namespace SistemadeTarefas.Repositarios.Interfaces
{
    public interface IPedidosRepositorio
    {
        Task<List<PedidosModel>> BuscarTodosPedidos();
        Task<PedidosModel> BuscarPorId(int id);
        Task<PedidosModel> Adicionar(PedidosModel Pedidos);
        Task<PedidosModel> Atualizar(PedidosModel Pedidos, int id);
        Task<bool> Apagar(int id);
    }
}
