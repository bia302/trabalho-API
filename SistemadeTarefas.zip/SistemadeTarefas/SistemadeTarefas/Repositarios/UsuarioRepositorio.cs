﻿using Microsoft.EntityFrameworkCore;
using SistemadeTarefas.Data;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Repositarios
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly SistemaTarefasDbContext _Dbcontext;

        public UsuarioRepositorio(SistemaTarefasDbContext SistemaTarefasContext)
        { 
           _Dbcontext = SistemaTarefasContext;
        }


       public async Task<UsuariosModel> BuscarPorId(int id)
        {
            return await _Dbcontext.Usuarios.FirstOrDefaultAsync(X => X.Id == id);
        }

        public async Task<List<UsuariosModel>> BuscarTodosUsuarios()
        {
            return await _Dbcontext.Usuarios.ToListAsync();
        }
        public async Task<UsuariosModel> Adicionar(UsuariosModel Usuario)
        {
            await _Dbcontext.Usuarios.AddAsync(Usuario);
            await _Dbcontext.SaveChangesAsync();

            return Usuario;
        }

        public async Task<bool> Apagar(int id)
        {
            UsuariosModel usuario = await BuscarPorId(id);
            if (usuario == null)
            {
                throw new Exception($"Usuário do id: {id} não foi encontrado.");
            }

            _Dbcontext.Usuarios.Remove(usuario);
            await _Dbcontext.SaveChangesAsync();
            return true;
        }


        public async Task<UsuariosModel> Atualizar(UsuariosModel usuario, int id)
        {
            UsuariosModel usuarioPorId = await BuscarPorId(id);

            if (usuarioPorId == null)
            {
                throw new Exception($"Usuário do id: {id} não foi encontrado.");
            }
            usuarioPorId.Nome = usuario.Nome;
            usuarioPorId.Email = usuario.Email;

            _Dbcontext.Usuarios.Update(usuarioPorId);
            await _Dbcontext.SaveChangesAsync();

            return usuarioPorId;
        }


    }
}
