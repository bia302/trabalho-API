﻿using Microsoft.EntityFrameworkCore;
using SistemadeTarefas.Data;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Repositarios
{
    public class CategoriaRepositorio : ICategoriaRepositorio
    {
        private readonly SistemaTarefasDbContext _Dbcontext;

        public CategoriaRepositorio(SistemaTarefasDbContext SistemaTarefasContext)
        {
            _Dbcontext = SistemaTarefasContext;
        }


        public async Task<CategoriaModel> BuscarPorIdCategoria(int id)
        {
            return await _Dbcontext.Categoria.FirstOrDefaultAsync(X => X.Id == id);
        }

        public async Task<List<CategoriaModel>> BuscarTodasCategoria()
        {
            return await _Dbcontext.Categoria.ToListAsync();
        }
        public async Task<CategoriaModel> Adicionar(CategoriaModel Categoria)
        {
            await _Dbcontext.Categoria.AddAsync(Categoria);
            await _Dbcontext.SaveChangesAsync();

            return Categoria;
        }

        public async Task<bool> Apagar(int id)
        {
            CategoriaModel Categoria = await BuscarPorIdCategoria(id);
            if (Categoria == null)
            {
                throw new Exception($"Categoria do id: {id} não foi encontrado.");
            }

            _Dbcontext.Categoria.Remove(Categoria);
            await _Dbcontext.SaveChangesAsync();
            return true;
        }


        public async Task<CategoriaModel> Atualizar(CategoriaModel Categoria, int id)
        {
            CategoriaModel CategoriaPorId = await BuscarPorIdCategoria(id);

            if (CategoriaPorId == null)
            {
                throw new Exception($"Categoria do id: {id} não foi encontrado.");
            }
            CategoriaPorId.Nome = Categoria.Nome;
            CategoriaPorId.Status = Categoria.Status;

            _Dbcontext.Categoria.Update(CategoriaPorId);
            await _Dbcontext.SaveChangesAsync();

            return CategoriaPorId;
        }


    }
}
    

