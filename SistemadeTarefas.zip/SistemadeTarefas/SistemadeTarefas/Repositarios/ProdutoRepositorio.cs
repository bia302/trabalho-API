﻿using Microsoft.EntityFrameworkCore;
using SistemadeTarefas.Data;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Repositarios
{
    public class ProdutosRepositorio : IProdutoRepositorio
    {
        private readonly SistemaTarefasDbContext _Dbcontext;

        public ProdutosRepositorio(SistemaTarefasDbContext SistemaTarefasContext)
        {
            _Dbcontext = SistemaTarefasContext;
        }


        public async Task<ProdutosModel> BuscarPorId(int id)
        {
            return await _Dbcontext.Produtos.FirstOrDefaultAsync(X => X.Id == id);
        }

        public async Task<List<ProdutosModel>> BuscarTodosProdutos()
        {
            return await _Dbcontext.Produtos.ToListAsync();
        }
        public async Task<ProdutosModel> Adicionar(ProdutosModel Produtos)
        {
            await _Dbcontext.Produtos.AddAsync(Produtos);
            await _Dbcontext.SaveChangesAsync();

            return Produtos;
        }

        public async Task<bool> Apagar(int id)
        {
            ProdutosModel Produtos = await BuscarPorId(id);
            if (Produtos == null)
            {
                throw new Exception($"Produtos do id: {id} não foi encontrado.");
            }

            _Dbcontext.Produtos.Remove(Produtos);
            await _Dbcontext.SaveChangesAsync();
            return true;
        }


        public async Task<ProdutosModel> Atualizar(ProdutosModel Produtos, int id)
        {
            ProdutosModel ProdutosPorId = await BuscarPorId(id);

            if (ProdutosPorId == null)
            {
                throw new Exception($"Produtos do id: {id} não foi encontrado.");
            }
            ProdutosPorId.Nome = Produtos.Nome;
            ProdutosPorId.Descricao = Produtos.Descricao;
            ProdutosPorId.Preço = Produtos.Preço;



            _Dbcontext.Produtos.Update(ProdutosPorId);
            await _Dbcontext.SaveChangesAsync();

            return ProdutosPorId;
        }
    }
}
