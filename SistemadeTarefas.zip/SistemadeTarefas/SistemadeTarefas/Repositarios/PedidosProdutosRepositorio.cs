﻿using Microsoft.EntityFrameworkCore;
using SistemadeTarefas.Data;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Repositarios
{
    public class PedidosProdutosRepositorio : IPedidosProdutosRepositorio
    {
        private readonly SistemaTarefasDbContext _Dbcontext;

        public PedidosProdutosRepositorio(SistemaTarefasDbContext SistemaTarefasContext)
        {
            _Dbcontext = SistemaTarefasContext;
        }


        public async Task<PedidosProdutosModel> BuscarPorId(int id)
        {
            return await _Dbcontext.PedidosProdutos.FirstOrDefaultAsync(X => X.Id == id);
        }

        public async Task<List<PedidosProdutosModel>> BuscarTodosPedidosProdutos()
        {
            return await _Dbcontext.PedidosProdutos.ToListAsync();
        }
        public async Task<PedidosProdutosModel> Adicionar(PedidosProdutosModel PedidosProdutos)
        {
            await _Dbcontext.PedidosProdutos.AddAsync(PedidosProdutos);
            await _Dbcontext.SaveChangesAsync();

            return PedidosProdutos;
        }

        public async Task<bool> Apagar(int id)
        {
            PedidosProdutosModel PedidosProdutos = await BuscarPorId(id);
            if (PedidosProdutos == null)
            {
                throw new Exception($"PedidosProdutos do id: {id} não foi encontrado.");
            }

            _Dbcontext.PedidosProdutos.Remove(PedidosProdutos);
            await _Dbcontext.SaveChangesAsync();
            return true;
        }


        public async Task<PedidosProdutosModel> Atualizar(PedidosProdutosModel PedidosProdutos, int id)
        {
            PedidosProdutosModel PedidosProdutosPorId = await BuscarPorId(id);

            if (PedidosProdutosPorId == null)
            {
                throw new Exception($"PedidosProdutos do id: {id} não foi encontrado.");
            }
            PedidosProdutosPorId.ProdutoId = PedidosProdutos.ProdutoId;
            PedidosProdutosPorId.CategoriaId = PedidosProdutos.CategoriaId;
            PedidosProdutosPorId.quantidade = PedidosProdutos.quantidade;

            _Dbcontext.PedidosProdutos.Update(PedidosProdutosPorId);
            await _Dbcontext.SaveChangesAsync();

            return PedidosProdutosPorId;
        }


    }
}


