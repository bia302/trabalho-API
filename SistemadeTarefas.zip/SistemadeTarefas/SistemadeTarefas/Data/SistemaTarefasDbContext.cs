﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using SistemadeTarefas.Data.Map;
using SistemadeTarefas.Models;

namespace SistemadeTarefas.Data
{
    public class SistemaTarefasDbContext : DbContext
        {
        public SistemaTarefasDbContext(DbContextOptions<SistemaTarefasDbContext> options)
            : base(options)
        {
        }
            public DbSet<CategoriaModel> Categoria { get; set; }
            public DbSet<PedidosModel> Pedidos { get; set; }
            public DbSet<PedidosProdutosModel> PedidosProdutos { get; set; }
            public DbSet<ProdutosModel> Produtos { get; set; }
            public DbSet<UsuariosModel> Usuarios { get; set; }
        

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                modelBuilder.ApplyConfiguration(new CategoriaMap());
                modelBuilder.ApplyConfiguration(new PedidosMap());
                modelBuilder.ApplyConfiguration(new PedidosProdutosMap());
                modelBuilder.ApplyConfiguration(new ProdutoMap());
                modelBuilder.ApplyConfiguration(new UsuarioMap());
                base.OnModelCreating(modelBuilder);
            }
    }
}
