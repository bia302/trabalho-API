﻿using Microsoft.AspNetCore.Mvc;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class PedidosProdutosController : ControllerBase
    {
        public readonly IPedidosProdutosRepositorio _PedidosProdutosRepositorio;

        public PedidosProdutosController(IPedidosProdutosRepositorio PedidosProdutosRepositorio)
        {
            _PedidosProdutosRepositorio = PedidosProdutosRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<PedidosProdutosModel>>> BuscarTodosPedidosProdutos()
        {
            List<PedidosProdutosModel> PedidosProdutos = await _PedidosProdutosRepositorio.BuscarTodosPedidosProdutos();
            return Ok(PedidosProdutos);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<List<PedidosProdutosModel>>> BuscarPorId(int id)
        {
            PedidosProdutosModel PedidosProdutos = await _PedidosProdutosRepositorio.BuscarPorId(id);
            return Ok(PedidosProdutos);
        }
        [HttpPost]
        public async Task<ActionResult<PedidosProdutosModel>> Adicionar([FromBody] PedidosProdutosModel PedidosModel)
        {
            PedidosProdutosModel Pedidos = await _PedidosProdutosRepositorio.Adicionar(PedidosModel);
            return Ok(Pedidos);
        }
        [HttpPut]
        public async Task<ActionResult<PedidosProdutosModel>> Atualizar(int id, [FromBody]PedidosProdutosModel pedidosProdutosModel)
        {
            pedidosProdutosModel.Id = id;
            PedidosProdutosModel PedidosProdutos = await _PedidosProdutosRepositorio.Atualizar(PedidosProdutos: pedidosProdutosModel, id);
            return Ok(PedidosProdutos);
        }
        [HttpDelete("{id}")]

        public async Task<ActionResult<PedidosProdutosModel>> Apagar(int id)
        {
            bool apagado = await _PedidosProdutosRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
