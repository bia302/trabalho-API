﻿using Microsoft.AspNetCore.Mvc;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class CategoriaController : ControllerBase
    {
        public readonly ICategoriaRepositorio _CategoriaRepositorio;

        public CategoriaController(ICategoriaRepositorio CategoriaRepositorio)
        {
            _CategoriaRepositorio = CategoriaRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<CategoriaModel>>> BuscarTodosCategoria()
        {
            List<CategoriaModel> Categoria = await _CategoriaRepositorio.BuscarTodasCategoria();
            return Ok(Categoria);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<List<CategoriaModel>>> BuscarPorIdCategoria(int id)
        {
            CategoriaModel Categoria = await _CategoriaRepositorio.BuscarPorIdCategoria(id);
            return Ok(Categoria);
        }
        [HttpPost]
        public async Task<ActionResult<CategoriaModel>> Adicionar([FromBody] CategoriaModel CategoriaModel)
        {
            CategoriaModel Categoria = await _CategoriaRepositorio.Adicionar(CategoriaModel);
            return Ok(Categoria);
        }
        [HttpPut]
        public async Task<ActionResult<CategoriaModel>> Atualizar(int id, [FromBody] CategoriaModel CategoriaModel)
        {
            CategoriaModel.Id = id;
            CategoriaModel Categoria = await _CategoriaRepositorio.Atualizar(CategoriaModel, id);
            return Ok(Categoria);
        }
        [HttpDelete("{id}")]

        public async Task<ActionResult<CategoriaModel>> Apagar(int id)
        {
            bool apagado = await _CategoriaRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
