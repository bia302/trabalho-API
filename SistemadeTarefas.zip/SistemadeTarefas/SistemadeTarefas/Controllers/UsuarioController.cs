﻿using Microsoft.AspNetCore.Mvc;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        public readonly IUsuarioRepositorio _usuarioRepositorio;

        public UsuarioController(IUsuarioRepositorio usuarioRepositorio)
        {
            _usuarioRepositorio = usuarioRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<UsuariosModel>>> BuscarTodosUsuarios()
        {
            List<UsuariosModel> usuarios = await _usuarioRepositorio.BuscarTodosUsuarios();
            return Ok(usuarios);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<List<UsuariosModel>>> BuscarPorId(int id)
        {
            UsuariosModel usuarios = await _usuarioRepositorio.BuscarPorId(id);
            return Ok(usuarios);
        }
        [HttpPost]
        public async Task<ActionResult<UsuariosModel>> Adicionar([FromBody] UsuariosModel usuarioModel)
        {
            UsuariosModel usuario = await _usuarioRepositorio.Adicionar(usuarioModel);
            return Ok(usuario);
        }
        [HttpPut]
        public async Task<ActionResult<UsuariosModel>> Atualizar(int id, [FromBody] UsuariosModel usuarioModel)
        {
            usuarioModel.Id = id;
            UsuariosModel usuario = await _usuarioRepositorio.Atualizar(usuarioModel, id);
            return Ok(usuario);
        }
        [HttpDelete("{id}")]

        public async Task<ActionResult<UsuariosModel>> Apagar(int id)
        {
            bool apagado = await _usuarioRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
