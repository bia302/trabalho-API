﻿using Microsoft.AspNetCore.Mvc;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class PedidosController : ControllerBase
    {
        public readonly IPedidosRepositorio _PedidosRepositorio;

        public PedidosController(IPedidosRepositorio PedidosRepositorio)
        {
            _PedidosRepositorio = PedidosRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<PedidosModel>>> BuscarTodosPedidos()
        {
            List<PedidosModel> Pedidos = await _PedidosRepositorio.BuscarTodosPedidos();
            return Ok(Pedidos);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<List<PedidosModel>>> BuscarPorId(int id)
        {
            PedidosModel Pedidos = await _PedidosRepositorio.BuscarPorId(id);
            return Ok(Pedidos);
        }
        [HttpPost]
        public async Task<ActionResult<PedidosModel>> Adicionar([FromBody] PedidosModel PedidosModel)
        {
            PedidosModel Pedidos = await _PedidosRepositorio.Adicionar(PedidosModel);
            return Ok(Pedidos);
        }
        [HttpPut]
        public async Task<ActionResult<PedidosModel>> Atualizar(int id, [FromBody] PedidosModel PedidosModel)
        {
            PedidosModel.Id = id;
            PedidosModel Pedidos = await _PedidosRepositorio.Atualizar(PedidosModel, id);
            return Ok(Pedidos);
        }
        [HttpDelete("{id}")]

        public async Task<ActionResult<PedidosModel>> Apagar(int id)
        {
            bool apagado = await _PedidosRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
