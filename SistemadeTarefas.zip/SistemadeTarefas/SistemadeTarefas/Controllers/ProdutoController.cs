﻿using Microsoft.AspNetCore.Mvc;
using SistemadeTarefas.Models;
using SistemadeTarefas.Repositarios.Interfaces;

namespace SistemadeTarefas.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class ProdutoController : ControllerBase
    {
        public readonly IProdutoRepositorio _ProdutoRepositorio;

        public ProdutoController(IProdutoRepositorio ProdutoRepositorio)
        {
            _ProdutoRepositorio = ProdutoRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<ProdutosModel>>> BuscarTodosProdutos()
        {
            List<ProdutosModel> Produtos = await _ProdutoRepositorio.BuscarTodosProdutos();
            return Ok(Produtos);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<List<ProdutosModel>>> BuscarPorId(int id)
        {
            ProdutosModel Produtos = await _ProdutoRepositorio.BuscarPorId(id);
            return Ok(Produtos);
        }
        [HttpPost]
        public async Task<ActionResult<ProdutosModel>> Adicionar([FromBody] ProdutosModel ProdutoModel)
        {
            ProdutosModel Produto = await _ProdutoRepositorio.Adicionar(ProdutoModel);
            return Ok(Produto);
        }
        [HttpPut]
        public async Task<ActionResult<ProdutosModel>> Atualizar(int id, [FromBody] ProdutosModel ProdutoModel)
        {
            ProdutoModel.Id = id;
            ProdutosModel Produto = await _ProdutoRepositorio.Atualizar(ProdutoModel, id);
            return Ok(Produto);
        }
        [HttpDelete("{id}")]

        public async Task<ActionResult<ProdutosModel>> Apagar(int id)
        {
            bool apagado = await _ProdutoRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
