﻿namespace SistemadeTarefas.Models
{
    public class UsuariosModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public string Email { get; set; }

        public DateOnly DatadeNascimento { get; set; }
    }
}
