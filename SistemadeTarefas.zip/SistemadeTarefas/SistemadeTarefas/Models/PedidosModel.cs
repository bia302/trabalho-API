﻿namespace SistemadeTarefas.Models
{
    public class PedidosModel
    {
        public int Id { get; set; }
        public int? usuarioId { get; set; }
        public virtual UsuariosModel? Usuario { get; set; }
        public string DataEntrega { get; set; }

    }
}

