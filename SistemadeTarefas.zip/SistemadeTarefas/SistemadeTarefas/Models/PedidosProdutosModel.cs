﻿namespace SistemadeTarefas.Models
{
    public class PedidosProdutosModel
    {
        internal int Id;

        public int? ProdutoId { get; set; }
        public virtual ProdutosModel? Produto { get; set; }

        public int? CategoriaId { get; set; }
        public virtual CategoriaModel? Categoria { get; set; }

        public int quantidade { get; set; }
    }
}
